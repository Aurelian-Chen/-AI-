import streamlit as st

st.title("简单测试应用")
st.write("如果看到这个消息，表示Streamlit可以正常运行。")